# -*- coding: utf-8 -*-
{
    'name' : 'Property',
    'version' : '18.0.3.0.0',
    'category' : 'Property',
    'summary' : 'Create different properties and store their details',
    'description' : """
Create different properties and store their details
===================================================

Different properties are created and their details including image, address , different monetary values are stored.
Their status can be tracked and a chatter box is also included.
     """,
    'depends': [
        'base',
        'mail',
        'account',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/property_data.xml',
        'data/sequence_number.xml',
        'views/property_property_views.xml',
        'views/property_rental_lease_views.xml',
        'views/property_facility_views.xml',
        'views/res_partner_property_views.xml',
        'views/property_menus.xml',
    ],
    'installable' : True,
    'application' : True,
    'auther'  : 'Najiya',
    'website' : 'http://localhost:8018/odoo/action-404',
}
