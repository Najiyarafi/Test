# -*- coding: utf-8 -*-
from . import property_property
from . import property_rental_lease
from  . import property_lines
from . import property_facility
from . import res_partner_property
