# -*- coding: utf-8 -*-
"""property facility"""
from odoo import fields,models


class PropertyFacility(models.Model):
    _name = 'property.facility'
    _description = 'Facility'
    _rec_name = 'facility_name'

    facility_name = fields.Char(required=True)

    _sql_constraints = [('unique_facility_name', 'unique(facility_name)', 'Property facility already exists')]
