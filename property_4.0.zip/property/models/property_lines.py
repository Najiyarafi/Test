
# -*- coding: utf-8 -*-
"""property lines"""
from odoo import api, fields, models


class PropertyLines(models.Model):
    """defining fields"""
    _name = 'property.lines'
    _description = 'Property Lines'

    property_rental_lease_id = fields.Many2one('property.rental.lease')
    property_id = fields.Many2one('property.property')
    type = fields.Selection(related='property_rental_lease_id.property_type')
    states = fields.Selection(related='property_rental_lease_id.states')
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id)
    rent = fields.Monetary(related='property_id.rent', currency_field='currency_id')
    lease = fields.Monetary(related='property_id.lease', currency_field='currency_id')
    amount = fields.Monetary(compute='_compute_amount', currency_field='currency_id', readonly=False,store=True ,
                             inverse="_inverse_amount")
    sub_total = fields.Monetary(currency_field='currency_id', compute='_compute_sub_total')
    qty_ordered = fields.Float(string='Ordered', compute='_compute_qty_ordered', store=True, readonly=False)
    qty_invoiced = fields.Float(string='Invoiced', store=True, compute='_compute_qty_invoiced')
    invoice_line_ids = fields.Many2many(
        'account.move.line', relation='property_line_account_move_line_rel',
        column1='property_line_id', column2='invoice_line_id',
    )

    @api.depends('property_rental_lease_id.total_days','amount','property_rental_lease_id.property_type')
    def _compute_sub_total(self):
        """computing total amount"""
        for record in self:
            record.sub_total = record.amount * record.property_rental_lease_id.total_days
    @api.depends('property_rental_lease_id.total_days')
    def _compute_qty_ordered(self):
        """setting ordered quantity"""
        for record in self:
            record.qty_ordered = record.property_rental_lease_id.total_days

    @api.depends('invoice_line_ids', 'invoice_line_ids.quantity','invoice_line_ids.move_id.state')
    def _compute_qty_invoiced(self):
        """calculating invoiced quantity"""
        for record in self:
            record.qty_invoiced = sum(record.invoice_line_ids.mapped('quantity')) - sum(
                record.invoice_line_ids.filtered(lambda rec: rec.move_id.state=='cancel').mapped('quantity'))

    @api.depends('type','property_id')
    def _compute_amount(self):
        """computing rent/lease price"""
        for record in self:
            if record.type == 'rent':
                record.amount = record.property_id.rent
            else:
                record.amount = record.property_id.lease

    def _inverse_amount(self):
        """changing amount of property"""
        for record in self:
            if record.type == 'rent':
                record.property_id.rent= record.amount
            else:
                record.property_id.lease = record.amount
