# -*- coding: utf-8 -*-
"""property model"""
from odoo import api,fields,models


class PropertyProperty(models.Model):
    """defining fields for the model"""
    _name = 'property.property'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = 'Property Property'

    name = fields.Char(required= True, string= "Name")
    address = fields.Text(string= 'Address')
    country_id = fields.Many2one('res.country')
    state_id = fields.Many2one('res.country.state')
    street = fields.Char(string= 'Street')
    street2 = fields.Char(string= 'Street2')
    city = fields.Char(string= 'City')
    property_img = fields.Image(string= 'Image')
    built_date = fields.Datetime(string= 'Built Date')
    can_be_sold = fields.Boolean(string= 'Can be Sold')
    currency_id = fields.Many2one('res.currency', default= lambda self: self.env.company.currency_id)
    legal_amount = fields.Monetary(string='Legal Amount', currency_field= 'currency_id')
    rent = fields.Monetary(string="Rent", help= 'Rent per day', currency_field= 'currency_id')
    lease = fields.Monetary(string='Lease', currency_field= 'currency_id')
    status = fields.Selection(
        string= 'Status',
        selection= [('draft','Draft'),('rented','Rented'),('leased','Leased'),('sold','Sold')],
        default= 'draft',
        tracking= True
    )
    description = fields.Text(string= 'Description')
    partner_id = fields.Many2one('res.partner', string= 'Owner')
    facility_ids = fields.Many2many('property.facility', string= "Facilities")
    related_list_count = fields.Integer(compute= '_compute_related_list_count')

    def _compute_related_list_count(self):
        """calculating related list count"""
        for record in self:
            related_lease_rent_list = self.env['property.lines'].search(
                [('property_id','=',self.id)]).mapped('property_rental_lease_id').ids
            related_lease_rent_count = len(related_lease_rent_list)
            if not related_lease_rent_list:
                record.related_list_count = 0
            else:
                record.related_list_count = related_lease_rent_count

    def unlink(self):
        """deleting rental/lease record when deleting a property"""
        for record in self:
            rental_lease_record = self.env['property.lines'].search(
                [('property_id', '=', record.id)]).mapped('property_rental_lease_id')
            print(rental_lease_record.property_line_ids.ids)
            if len(rental_lease_record.property_line_ids.ids)==1:
                rental_lease_record.unlink()
            else:
                line_ids = rental_lease_record.property_line_ids.filtered(lambda x: x.property_id == record)
                line_ids.unlink()
        return super().unlink()

    def action_view_rl(self):
        """fetch rental/lease record list"""
        related_lease_rent_list = self.env['property.lines'].search(
            [('property_id','=',self.id)]).mapped('property_rental_lease_id').ids
        return{
            "type":'ir.actions.act_window',
            'res_model': 'property.rental.lease',
            'view_mode': 'list,form',
            'name' : "Related list",
            'domain':[('id', 'in', related_lease_rent_list)],
        }





