# -*- coding: utf-8 -*-
"""Property.rental.lease Model"""
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, Command
from odoo.exceptions import ValidationError


class PropertyRentalLease(models.Model):
    """declaring necessary fields """
    _name = 'property.rental.lease'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = 'Property Rental Lease'
    _rec_name = 'sequence'

    invoice_ids = fields.Many2many('account.move')
    property_type = fields.Selection(string='Type', selection= [('rent','Rent'),('lease','Lease')], default = 'rent')
    partner_id = fields.Many2one('res.partner', string= 'Tenant', required=True)
    currency_id = fields.Many2one('res.currency', default= lambda self: self.env.company.currency_id)
    rent_amount = fields.Monetary(string= 'Rent Amount', help= 'Rent per day', currency_field= 'currency_id')
    lease_amount = fields.Monetary(string= 'Lease Amount', currency_field= 'currency_id')
    date_from = fields.Datetime('Start Date', copy= False, default= fields.Datetime.now())
    date_to = fields.Datetime('End Date', copy= False, default= fields.Datetime.now()+ relativedelta(hours=1))
    states = fields.Selection(
        string= 'States',
        selection= [('draft','Draft'),('confirmed','Confirmed'),('closed','Closed'),('returned','Returned'),
                    ('expired','Expired')],
        default= 'draft', tracking=True )
    total_days = fields.Float(compute= '_compute_total_days')
    total_amount = fields.Monetary(string= 'Total Amount', compute= '_compute_total_amount')
    company_id = fields.Many2one('res.company', string= 'Company', default= lambda self: self.env.company,
                                 readonly= True)
    sequence = fields.Char(string= "Sequence", default= 'New', readonly= True)
    property_line_ids = fields.One2many('property.lines', inverse_name= "property_rental_lease_id")
    property_invoice_count = fields.Integer(compute='_compute_property_invoice_count')
    invoice_status = fields.Selection(
        selection=[('invoiced','Fully Invoiced'),('partially_invoiced','Partially Invoiced'),
                   ('to_invoice','To Invoice'),('paid','Paid'),('partially_paid','Partially Paid')],
        string="Invoice Status",
        compute='_compute_invoice_status',
        store=True)

    @api.depends('invoice_ids.payment_state','invoice_ids.state','property_line_ids.qty_ordered',
                 'property_line_ids.qty_invoiced')
    def _compute_invoice_status(self):
        """computing invoice status"""
        for record in self:
            if not record.invoice_ids or record.invoice_ids.filtered(lambda rec: rec.state=='draft'):
                record.invoice_status = 'to_invoice'
            elif sum(record.property_line_ids.mapped('qty_ordered')) > sum(record.property_line_ids.mapped('qty_invoiced')):
                if record.invoice_ids.filtered(lambda rec: rec.payment_state in ['partial','paid']):
                    record.invoice_status = 'partially_paid'
                else:
                    record.invoice_status = 'partially_invoiced'
            elif not record.invoice_ids.filtered(lambda rec: rec.state=='draft') and sum(
                    record.property_line_ids.mapped('qty_ordered'))==sum(record.property_line_ids.mapped('qty_invoiced')):
                if all(rec.payment_state=='paid' for rec in record.invoice_ids.filtered(lambda rec:rec.state=='posted')):
                    record.invoice_status = 'paid'
                elif record.invoice_ids.filtered(lambda rec: rec.payment_state=='partial') or any(
                        rec.payment_state == 'paid' for rec in record.invoice_ids) :
                    record.invoice_status = 'partially_paid'
                else:
                    record.invoice_status = 'invoiced'

    def _compute_property_invoice_count(self):
        """calculating invoice count"""
        for record in self:
            if not record.invoice_ids:
                record.property_invoice_count = 0
            record.property_invoice_count = len(record.invoice_ids.ids)

    @api.depends('date_from','date_to')
    def _compute_total_days(self):
        """computing total from rental/lease period"""
        for record in self:
            total_sec = (record.date_to - record.date_from).total_seconds()
            record.total_days = round(abs(total_sec/86400),2)

    @api.depends('property_line_ids.sub_total','property_line_ids.rent','property_line_ids.lease')
    def _compute_total_amount(self):
        """computing total amount from rent/lease amount"""
        for record in self:
            record.total_amount = sum(record.property_line_ids.mapped('sub_total'))

    @api.model
    def create(self, vals):
        """generating unique sequence number"""
        vals['sequence'] = self.env['ir.sequence'].next_by_code('sequence_no_code')
        return super(PropertyRentalLease, self).create(vals)

    def action_create_invoice(self):
        """creating invoice"""
        if not self.invoice_ids:
            created_invoice_records = self.env['account.move'].create([{
                'move_type': 'out_invoice',
                'partner_id': self.partner_id.id,
                'invoice_date': fields.Date.today(),
            }])
            self.write({'invoice_ids': [Command.link(created_invoice_records.id)]})
            for line in self.property_line_ids:
                created_invoice_line_record = self.env['account.move.line'].create([{
                    'move_id': created_invoice_records.id,
                    'name': line.property_id.name,
                    'quantity': line.qty_ordered,
                    'price_unit' : line.amount,
                }])
                line.write({'invoice_line_ids': [Command.link(created_invoice_line_record.id)]})
                body_inbound = "Invoice created : " + created_invoice_records._get_html_link()
            self.message_post(body=body_inbound)
        elif self.property_line_ids.filtered(lambda rec: rec.qty_ordered != rec.qty_invoiced) :
            if self.invoice_ids.filtered(lambda rec: rec.state=='draft'):
                created_invoice_records = self.invoice_ids.filtered(lambda rec: rec.state=='draft')
            else:
                created_invoice_records = self.env['account.move'].create([{
                                   'move_type': 'out_invoice',
                                   'partner_id': self.partner_id.id,
                                   'invoice_date': fields.Date.today(),
                               }])
                body_inbound = "Invoice created : " + created_invoice_records._get_html_link()
                self.message_post(body=body_inbound)
                self.write({'invoice_ids': [Command.link(created_invoice_records.id)]})
            for line in self.property_line_ids:
                if line.qty_ordered > sum(line.invoice_line_ids.filtered(
                        lambda rec:rec.move_id.state in ['draft','posted']).mapped('quantity')):
                    if 'draft' in line.invoice_line_ids.move_id.mapped('state'):
                        draft_record = line.invoice_line_ids.filtered(
                            lambda rec: rec.name == line.property_id.name and rec.move_id.state == 'draft')
                        posted_record = line.invoice_line_ids.filtered(
                            lambda rec: rec.name == line.property_id.name and rec.move_id.state == 'posted')
                        draft_record.write({
                            'quantity': line.qty_ordered - sum(posted_record.filtered(
                                lambda rec: rec.name == line.property_id.name).mapped('quantity'))
                        })
                        self.message_post(body='Invoice updated')
                    else:
                        created_invoice_line_record = self.env['account.move.line'].create([{
                            'move_id': created_invoice_records.id,
                            'name': line.property_id.name,
                            'quantity': line.qty_ordered - sum(
                                line.invoice_line_ids.filtered(
                                    lambda rec:rec.move_id.state=='posted').mapped('quantity')),
                            'price_unit': line.amount,
                        }])
                        line.write({'invoice_line_ids': [Command.link(created_invoice_line_record.id)]})
        else:
            self.message_post(body=' Nothing to invoice')

    def action_set_draft(self):
        """setting to draft state"""
        self.states = 'draft'
        self.property_line_ids.property_id.status = 'draft'

    def action_set_confirm(self):
        """checking if there is any attachments while saving and if not raising an error and
        changing into corresponding state"""
        attachment_list = self.env['ir.attachment'].search([('res_model','=','property.rental.lease'),
                                                            ('res_id', '=', self.id)])
        if  not  attachment_list:
            raise ValidationError("No attachment present")
        self.states = 'confirmed'
        if self.property_type == 'rent':
            self.property_line_ids.property_id.status = 'rented'
        elif self.property_type == "lease":
            self.property_line_ids.property_id.status = 'leased'

    def action_set_close(self):
        """setting states as close when clicking respective button and changing corresponding state"""
        self.states = 'closed'
        self.property_line_ids.property_id.status = 'draft'

    def action_set_return(self):
        """setting states as return when clicking respective button and changing corresponding state"""
        self.states = 'returned'
        self.property_line_ids.property_id.status = 'draft'

    def action_set_expired(self):
        """setting states as expired when clicking respective button and changing corresponding state"""
        self.states = 'expired'
        self.property_line_ids.mapped('property_id').write({
            'status': 'draft',
        })

    def action_view_inv(self):
        """fetching invoice from smart button"""
        return {
            "type" : 'ir.actions.act_window',
            'res_model' : 'account.move',
            "view_mode" : 'list,form',
            'domain' : [('id','in',self.invoice_ids.ids)]
        }
