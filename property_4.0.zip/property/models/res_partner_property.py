# -*- coding: utf-8 -*-
from odoo import fields, models


class ResPartnerProperty(models.Model):
    _inherit = 'res.partner'

    related_property_count = fields.Integer(compute='_compute_related_property_count')

    def _compute_related_property_count(self):
        """calculating related property count"""
        for record in self:
            record.related_property_count = self.env['property.property'].search_count([('partner_id','=', self.id)])

    def action_view_property(self):
        """fetch property owned"""
        return {
            'type' : 'ir.actions.act_window',
            'res_model' : 'property.property',
            'views' : [(self.env.ref('property.related_property_list_view').id,'list')],
            'name' : 'Related Property',
            'domain' : [('partner_id','=',self.id)]
        }
